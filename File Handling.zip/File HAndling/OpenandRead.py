file = open("C:/Users/Sajid/OneDrive/Desktop/Sajid/Python/File HAndling/myfile.txt", "r")
content = file.read()
print(content)
file.close()
