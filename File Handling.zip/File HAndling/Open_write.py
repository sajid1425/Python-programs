file=open('C:/Users/mahab/Downloads/New folder (2)/sample2.txt','w')
#Delete the previous content and add the following content
file.write("Hi this sample2")
file.close

