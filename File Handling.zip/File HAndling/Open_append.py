#open file in append mode for writing
file=open('C:/Users/mahab/Downloads/New folder (2)/sample2.txt','a')
#Keep the previous content as it is and append
file.write("  Hi this sample3 append")